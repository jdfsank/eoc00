node scripts/round21-training-choice-balance.mjs
