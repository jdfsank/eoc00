import {createRequire} from 'node:module';
import fs from 'node:fs/promises';
import {pathToFileURL} from 'node:url';
import * as sim from '../eoc00-round42-recovery/src/simulation.js';
import {ready} from '../eoc00-round42-recovery/tests/fixtures/pre-training-workload-scenarios.js';
const require=createRequire(new URL('../eoc00-round42-recovery/package.json',import.meta.url));
const {chromium}=require('playwright'),binary=require('@sparticuz/chromium');
const {createServer}=await import(pathToFileURL(require.resolve('vite')));
const out='../round44-work/independent-focus';await fs.mkdir(out,{recursive:true});
let server,browser;const result={errors:[],stages:[]};
try{
 server=await createServer({server:{host:'127.0.0.1',port:4845,strictPort:true}});await server.listen();
 browser=await chromium.launch({executablePath:await binary.executablePath(),args:binary.args,headless:true});const page=await browser.newPage({viewport:{width:320,height:568}});page.setDefaultTimeout(12000);page.on('pageerror',e=>result.errors.push(e.message));
 await page.goto('http://127.0.0.1:4845');await page.locator('.selection-card').waitFor();
 const click=a=>page.locator(`[data-action="${a}"]`).first().click();
 const s=ready(sim),original=JSON.stringify(s);
 await click('settings');await page.locator('#import-save').setInputFiles({name:'focus.json',mimeType:'application/json',buffer:Buffer.from(JSON.stringify({state:s,ui:{bigText:true}}))});await page.locator('.selection-card').waitFor();if(await page.locator('.toast').count())await page.locator('.toast').waitFor({state:'hidden',timeout:6000});
 await click('home');await page.locator('[data-action="actor"][data-actor="protagonist"]').click();await click('list');await page.locator('[data-action="select"][data-cell="E4"]').click();await page.locator('[data-primary-action]').click();await page.locator('[data-action="choose"][data-id="train_network"]').click();
 async function record(name){const data=await page.evaluate(()=>{const a=document.activeElement,r=a.getBoundingClientRect(),h=document.querySelector('main h1')?.getBoundingClientRect(),b=document.querySelector('[data-opportunity-reading-return]')?.getBoundingClientRect();return {active:{tag:a.tagName,text:a.textContent,top:r.top,bottom:r.bottom,height:r.height},heading:h?{top:h.top,bottom:h.bottom}:null,banner:b?{top:b.top,bottom:b.bottom}:null,viewport:{width:innerWidth,height:innerHeight},scrollY,font:getComputedStyle(document.documentElement).fontSize,world:JSON.stringify(window.afterwave.state),savedWorld:JSON.stringify(JSON.parse(localStorage.getItem('afterwave.save.v1')).state),ui:window.afterwave.ui};});data.worldUnchanged=data.world===original&&data.savedWorld===original;delete data.world;delete data.savedWorld;result.stages.push({name,...data});await page.screenshot({path:`${out}/${name}.png`});}
 const link=page.locator('[data-action="opportunity-route"][data-id="companion"]');await link.scrollIntoViewIfNeeded();await page.keyboard.press('Tab');await link.focus();await page.keyboard.press('Enter');await page.locator('[data-opportunity-reading-return]').waitFor();await record('companion-target');
 await page.locator('[data-action="opportunity-return"]').scrollIntoViewIfNeeded();await page.locator('[data-action="opportunity-return"]').focus();await page.keyboard.press('Enter');await record('origin-return');
 console.log(JSON.stringify(result,null,2));
} catch(e){result.failure=String(e.stack||e);console.error(result.failure);process.exitCode=1;} finally {if(browser)await browser.close();if(server)await server.close();await fs.writeFile(`${out}/result.json`,JSON.stringify(result,null,2));}
