await page.addInitScript(()=>{
 window.returnProbe=[];
 const record=(type,extra={})=>{const imgs=[...document.querySelectorAll('main img')].map(e=>({src:e.getAttribute('src'),complete:e.complete,naturalWidth:e.naturalWidth,naturalHeight:e.naturalHeight,height:e.getBoundingClientRect().height}));window.returnProbe.push({type,time:performance.now(),screen:window.afterwave?.ui.screen,scroll:scrollY,docHeight:document.documentElement.scrollHeight,selection:String(getSelection()),imgs,...extra});if(window.returnProbe.length>250)window.returnProbe.shift();};
 for(const type of ['scroll','dblclick','selectionchange'])document.addEventListener(type,e=>record(type,{detail:e.detail}),true);
 document.addEventListener('load',e=>{if(e.target.tagName==='IMG')record('image-load',{src:e.target.getAttribute('src')});},true);
 document.addEventListener('click',e=>{const action=e.target.closest?.('[data-action]')?.dataset.action;if(action==='scene-source-return'){record('return-click-capture');queueMicrotask(()=>record('return-click-microtask'));requestAnimationFrame(()=>{record('return-frame1');requestAnimationFrame(()=>record('return-frame2'));});}},true);
 const native=window.scrollTo;window.scrollTo=function(...args){record('scrollTo-call',{args,stack:new Error().stack});return native.apply(this,args);};
 try{new PerformanceObserver(list=>{for(const e of list.getEntries())record('layout-shift',{value:e.value,sources:e.sources?.map(s=>({tag:s.node?.tagName,cls:s.node?.className,previous:s.previousRect,current:s.currentRect}))});}).observe({type:'layout-shift',buffered:true});}catch{}
});
