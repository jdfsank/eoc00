#!/bin/bash
set -u
cd /workspace/scratch/52f1b40b7635/eoc00-round42-recovery || exit 1
OUT=/workspace/scratch/52f1b40b7635/round42-recovered-full
run_stage() {
 name="$1"; shift
 date +%s.%N > "$OUT/$name.started"
 printf '%s\n' "$*" > "$OUT/$name.command"
 "$@" > "$OUT/$name.log" 2>&1
 code=$?
 printf '%s\n' "$code" > "$OUT/$name.exit"
 date +%s.%N > "$OUT/$name.finished"
 printf '%s exit=%s\n' "$name" "$code"
 if [ "$code" != 0 ]; then tail -100 "$OUT/$name.log"; exit "$code"; fi
}
run_stage unit npm test
run_stage build npm run build
run_stage browser npm run test:browser
run_stage matrix npm run test:outlook-matrix
run_stage tradeoffs node scripts/round21-training-choice-balance.mjs
run_stage roles node scripts/round22-role-opportunity-audit.mjs
printf 'All recovered stages completed\n'
